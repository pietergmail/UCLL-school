package model.korting;

/**
 * @author Pieter Herremans
 */

public enum KortingEnum {
    GEEN,
    GROEPKORTING,
    DREMPELKORTING,
    DUURSTEKORTING
}
