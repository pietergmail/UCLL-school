package model.database;

/**
 * @author Sateur Maxime
 */

public enum LoadSaveEnum {
    TEKST,
    EXCEL
}