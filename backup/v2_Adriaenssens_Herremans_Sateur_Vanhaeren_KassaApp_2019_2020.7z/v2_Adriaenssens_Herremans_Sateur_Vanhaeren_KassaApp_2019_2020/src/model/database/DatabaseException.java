package model.database;

/**
 * @author Herremans Pieter
 */

public class DatabaseException extends Throwable {

        public DatabaseException(String message){ super(message);}

}