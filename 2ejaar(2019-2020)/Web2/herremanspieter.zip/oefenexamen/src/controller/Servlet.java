package controller;
import domain.*;
import db.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/Servlet")
public class Servlet extends HttpServlet {
    BikeRepository bikes = new BikeRepository();
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processontroller(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processontroller(request, response);
    }

    protected void processontroller(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String command= "";
        if (request.getParameter("command") != null){
            command = (String)request.getParameter("command");
        }
        String destination = "";
        switch(command){
            case "home":
                destination = home(request, response);
                break;
            case"overview":
                destination = overview(request, response);
                break;
            case"detail":
                destination = detail(request, response);
                break;
            case"add":
                destination = add(request, response);
                break;
            default:
                destination = home(request, response);
        }
        request.getRequestDispatcher(destination).forward(request, response);

    }

    protected String home(HttpServletRequest Request, HttpServletResponse Response){
        return "index.jsp";
    }

    protected String overview(HttpServletRequest request, HttpServletResponse Response){
        request.setAttribute("bikes", bikes.getAll());
        return "bikeOverview.jsp";
    }

    protected String detail(HttpServletRequest request, HttpServletResponse Response){
        request.setAttribute("bike", bikes.get(request.getParameter("id")));
        return "bikeDetail.jsp";
    }

    protected String add(HttpServletRequest request, HttpServletResponse Response){
        return "bikeAdd.jsp";
    }

    protected String addBike(HttpServletRequest request, HttpServletResponse response){
        <ArrayList<String> errors = new ArrayList<>();

        Bike bike = new Bike();
        setId(bike, request, errors);
        setCat(bike, request, errors);
        setBrand(bike, request, errors);
        setDesc(bike, request, errors);
        setPrice(bike, request, errors);

        if (errors.size() == 0){
            bikes.add(bike);
            return overview(request, response);
        }else{
            request.setAttribute("errors", errors);
            return "bikeAdd.jsp";
        }
    }
}
