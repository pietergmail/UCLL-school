package be.ucll.oop;

public class DomainException extends Exception {
	public DomainException() {
	}

	public DomainException(String message) {
		super(message);
	}
}
