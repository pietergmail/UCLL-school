package be.ucll.oop.cargo;

/**
 * Dit is een marker interface, en bevat geen contract, maar wordt wel gebruikt om bepaalde klassen te markeren en zo een specifiek gedrag te kunnen toewijzen op basis van type; Serializable is ook een marker interface
 */
public interface GasOfVloeistofCargo {
}
