package be.ucll.oop;

public interface PrijsBerekenbaar {
	double berekenPrijs(int afstand);
}
