package util;

public class DomainException extends Exception {
	public DomainException(String message) {
		super(message);
	}
}
