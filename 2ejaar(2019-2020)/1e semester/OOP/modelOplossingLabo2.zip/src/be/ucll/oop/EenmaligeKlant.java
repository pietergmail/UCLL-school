package be.ucll.oop;

public class EenmaligeKlant extends Klant {
	private double totaalPrijs;

	public double getTotaalPrijs() {
		return totaalPrijs;
	}

	public void setTotaalPrijs(double totaalPrijs) {
		this.totaalPrijs = totaalPrijs;
	}
}
