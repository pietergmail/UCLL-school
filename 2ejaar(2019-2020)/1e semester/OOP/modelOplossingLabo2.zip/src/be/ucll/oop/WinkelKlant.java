package be.ucll.oop;

public class WinkelKlant extends EenmaligeKlant {
	private int aantalMaaltijden;

	public int getAantalMaaltijden() {
		return aantalMaaltijden;
	}

	public void setAantalMaaltijden(int aantalMaaltijden) {
		this.aantalMaaltijden = aantalMaaltijden;
	}
}
