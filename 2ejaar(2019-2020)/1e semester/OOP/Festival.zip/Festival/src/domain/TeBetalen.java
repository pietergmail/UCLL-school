package domain;

public interface TeBetalen {

    double getLoon();

}
