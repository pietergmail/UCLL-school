package domain;

public interface TeCompenseren {

    int getAantalGratisBonnetjes();

}
