package ui;

import domain.*;
import java.time.*;

public class FestivalApp {

    public static void main(String[] args){
        //TODO
        // Te lui om dit te maken maar het werkt wel :P
    }

}
