package be.ucll.oop;

public class Coordinaat {
	private final int lengteGraad;
	private final int breedteGraad;

	public Coordinaat(int lengteGraad, int breedteGraad) {
		this.lengteGraad = lengteGraad;
		this.breedteGraad = breedteGraad;
	}
}
