package be.ucll.oop;

public interface HavenActiviteit {
	public Haven getHaven();
	public void setHaven(Haven haven);
}
