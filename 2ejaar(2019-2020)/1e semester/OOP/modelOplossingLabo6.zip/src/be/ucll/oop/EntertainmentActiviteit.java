package be.ucll.oop;

public class EntertainmentActiviteit extends BoordActiviteitImpl {
}
