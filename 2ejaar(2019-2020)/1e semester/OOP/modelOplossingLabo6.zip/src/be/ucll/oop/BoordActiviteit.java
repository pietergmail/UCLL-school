package be.ucll.oop;

public interface BoordActiviteit {
	public String getLocatie();

	public void setLocatie(String locatie);
}
