package be.ucll.oop;

public class SportActiviteit extends BoordActiviteitImpl {
}
