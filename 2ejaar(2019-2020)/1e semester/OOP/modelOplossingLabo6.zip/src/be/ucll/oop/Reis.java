package be.ucll.oop;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Reis {
	private List<Activiteit> activiteiten;
	private List<String> passagiers;
	private List<Haven> stops;

	public Reis() {
		this.activiteiten = new ArrayList<>();
		this.passagiers = new ArrayList<>();
		this.stops = new LinkedList<>();
	}
}
