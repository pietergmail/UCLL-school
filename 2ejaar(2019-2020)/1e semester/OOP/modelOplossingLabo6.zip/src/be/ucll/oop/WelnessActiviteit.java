package be.ucll.oop;

public class WelnessActiviteit extends BoordActiviteitImpl {
}
