package domain;

public class getal() {

}
