package ui;
import domain.getal;

public class fibonacci{

}
public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
